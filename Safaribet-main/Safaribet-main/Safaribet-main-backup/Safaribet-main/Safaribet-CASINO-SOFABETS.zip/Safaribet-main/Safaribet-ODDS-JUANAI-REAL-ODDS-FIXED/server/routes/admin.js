const express = require('express');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const safeError = require('../utils/safeError');
const { requireAdmin } = require('../utils/adminAuth');
const User        = require('../models/User');
const Bet         = require('../models/Bet');
const Match       = require('../models/Match');
const Transaction = require('../models/Transaction');
const Promotion   = require('../models/Promotion');
const walletService = require('../services/walletService');
const router      = express.Router();

// ── ADMIN AUTH ──
// Real authentication now lives in routes/adminAuth.js (username + email +
// password + 6-digit TOTP code, issuing a signed JWT). This router just keeps
// a per-IP rate limit as defense-in-depth, then requires a valid token on
// every request via requireAdmin — there is no longer a single shared
// password checked directly against these routes.
const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300, // generous — real throttling now happens at the login gate itself; this just caps abuse of an already-valid session
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many admin requests. Try again later.' }
});

router.use(adminLimiter);
router.use(requireAdmin);

// ── IN-MEMORY STORE (settings, blacklist, content, audit) ──
// NOTE: `content` (banner/popup/notice) is now backed by MongoDB via SiteContent —
// see loadPersistedContent() below. The in-memory copy here is just a fast-read
// cache; the database is the source of truth and survives restarts/redeploys.
// The other fields (blacklist, settings, limits, bonusSettings) are still
// memory-only and will reset on redeploy — a separate, lower-urgency fix.
const store = {
  blacklist:   [],
  auditLog:    [],
  loginLog:    [],
  content:     { banner: '', notice: '', bannerLink: '', bannerImage: '', banners: [], popupLink: '', popupImage: '', popupEnabled: false },
  settings:    { maintenanceMode: false, maintenanceMessage: '', allowRegistration: true, allowDeposits: true, allowWithdrawals: true, siteName: 'SafariBet' },
  limits:      { minBet: 10, maxBet: 500000, maxSelections: 20, maxPayout: 1000000, minDeposit: 10, maxDeposit: 150000, minWithdrawal: 100, maxWithdrawal: 70000, wdPerDay: 3, platformMarginPercent: 0, liveMarginPercent: 0, withdrawalAutoApproveLimit: 1000 },
  bonusSettings:{ welcomeBonus: 20, minBonusDep: 0 },
  notifications:[],
  // ── LIVE ODDS RISK MANAGEMENT ──
  // Configurable rules for suspending live selections/markets when the score
  // gives one side a lead strong enough that continuing to offer odds risks
  // paying out on a stale/outdated price. See server/services/marketResolver.js
  // for how these are actually evaluated — this is just the admin-editable
  // config; the engine there re-evaluates match state fresh on every single
  // odds request and bet placement (never a stored "unlock at time X" timer),
  // so a selection only reopens once the underlying condition genuinely
  // clears, never just because time passed or odds were recalculated.
  liveRisk: {
    // Markets covered by the "leading side" suspension rules below. ou25/btts
    // have their own separate, always-on mathematically-certain checks
    // (e.g. BTTS "No" is impossible once both teams have scored) that aren't
    // part of this configurable list — those aren't judgment calls.
    affectedMarkets: ['1x2', 'dc', 'handicap'],
    // If a live match's score/minute data hasn't updated within this many
    // seconds (sync stalled, feed down, etc.), every live market on it is
    // suspended outright — uncertain state must default to LOCKED, never OPEN.
    dataFreshnessMaxAgeSec: 45,
    // After ANY goal, every live market on that match is suspended for this
    // many seconds while odds catch up to the new score — independent of the
    // minute/goal-diff rules below, since even a single goal invalidates the
    // pricing basis for every market on that match, not just 1X2.
    goalEventSuspensionSec: 45,
    // Level-score matches this close to full time are treated as draw-heavy
    // enough to suspend the Draw pick specifically (tighter window than the
    // goal-lead rules below, since a single goal flips this instantly).
    drawSuspendMinutesRemaining: 3,
    // Floor odds — anything priced at or below this offers no genuine value
    // and is suspended regardless of which rule (if any) triggered.
    minAcceptableOdds: 1.05,
    // Tiered rules, evaluated independently — ANY matching enabled rule
    // applies its action. 'suspend_leading' locks only the currently-leading
    // side's own win-pick (and any Double Chance/Handicap pick that leans on
    // it) — that's deliberately the locked side, not the trailing one: a
    // stale, too-generous price on the team that's ALREADY winning is what's
    // actually exploitable, not a stale price on the team that's losing.
    // 'suspend_market' locks the entire market (every outcome) for matches
    // regarded as effectively over.
    rules: [
      { id: 'r60',  enabled: true, minMinute: 60, minGoalDiff: 2, action: 'suspend_leading', label: "60'+ & 2-goal lead — suspend leading side" },
      { id: 'r70',  enabled: true, minMinute: 70, minGoalDiff: 2, action: 'suspend_leading', label: "70'+ & 2-goal lead — strong suspension" },
      { id: 'r75',  enabled: true, minMinute: 75, minGoalDiff: 3, action: 'suspend_leading', label: "75'+ & 3-goal lead — suspend leading side" },
      { id: 'r80',  enabled: true, minMinute: 80, minGoalDiff: 2, action: 'suspend_leading', label: "80'+ & 2-goal lead — very late, suspend leading side" },
      { id: 'r85m', enabled: true, minMinute: 85, minGoalDiff: 4, action: 'suspend_market',  label: "85'+ & 4-goal lead — suspend entire market" }
    ]
  }
};

(async function loadPersistedContent() {
  try {
    const SiteContent = require('../models/SiteContent');
    const doc = await SiteContent.findOne({ singleton: 'main' }).lean();
    if (doc) {
      store.content = {
        banner: doc.banner || '', bannerLink: doc.bannerLink || '', bannerImage: doc.bannerImage || '',
        banners: Array.isArray(doc.banners) ? doc.banners : [],
        notice: doc.notice || '', popupLink: doc.popupLink || '', popupImage: doc.popupImage || '',
        popupEnabled: !!doc.popupEnabled
      };
      console.log('[admin] Loaded persisted site content from database');
    }
  } catch (e) {
    console.error('[admin] Failed to load persisted content — using defaults:', e.message);
  }
})();

async function persistContent() {
  try {
    const SiteContent = require('../models/SiteContent');
    await SiteContent.findOneAndUpdate({ singleton: 'main' }, { $set: store.content }, { upsert: true });
  } catch (e) {
    console.error('[admin] Failed to persist site content:', e.message);
  }
}

// ── Persist settings/limits/bonusSettings/blacklist too, reusing the generic
// key-value Settings model already used by the referral system — avoids adding
// yet another one-off schema for what's really just admin-configured key/value data.
(async function loadPersistedConfig() {
  try {
    const settingsService = require('../models/Settings');
    const [savedSettings, savedLimits, savedBonus, savedBlacklist, savedLiveRisk] = await Promise.all([
      settingsService.get('admin_site_settings'),
      settingsService.get('admin_limits'),
      settingsService.get('admin_bonus_settings'),
      settingsService.get('admin_blacklist'),
      settingsService.get('admin_live_risk')
    ]);
    if (savedSettings) Object.assign(store.settings, savedSettings);
    if (savedLimits) Object.assign(store.limits, savedLimits);
    if (savedBonus) Object.assign(store.bonusSettings, savedBonus);
    if (Array.isArray(savedBlacklist)) store.blacklist = savedBlacklist;
    if (savedLiveRisk) Object.assign(store.liveRisk, savedLiveRisk); // shallow merge is enough — POST /live-risk below always sends the full object back, including a complete `rules` array, never a partial patch
    console.log('[admin] Loaded persisted settings/limits/bonus/blacklist/live-risk from database');
  } catch (e) {
    console.error('[admin] Failed to load persisted config — using defaults:', e.message);
  }
})();
async function persistSettings()     { try { await require('../models/Settings').set('admin_site_settings', store.settings); } catch(e) { console.error('[admin] persist settings failed:', e.message); } }
async function persistLimits()       { try { await require('../models/Settings').set('admin_limits', store.limits); } catch(e) { console.error('[admin] persist limits failed:', e.message); } }
async function persistBonusSettings(){ try { await require('../models/Settings').set('admin_bonus_settings', store.bonusSettings); } catch(e) { console.error('[admin] persist bonus settings failed:', e.message); } }
async function persistBlacklist()    { try { await require('../models/Settings').set('admin_blacklist', store.blacklist); } catch(e) { console.error('[admin] persist blacklist failed:', e.message); } }
async function persistLiveRisk()     { try { await require('../models/Settings').set('admin_live_risk', store.liveRisk); } catch(e) { console.error('[admin] persist live-risk failed:', e.message); } }

function audit(action, data) {
  store.auditLog.unshift({ action, data, time: new Date().toISOString() });
  if (store.auditLog.length > 500) store.auditLog.pop();
}

// Expose store for other routes (attached to router since module.exports = router happens once, at file end)
router.getStore = () => store;

// ── STATS ──
router.get('/stats', async (req, res) => {
  try {
    const [users, bets, pending, depAgg, wdAgg, wonAgg, liveMatches, upcomingMatches, recent] = await Promise.all([
      User.countDocuments(),
      Bet.countDocuments(),
      Bet.countDocuments({ status: 'pending' }),
      Transaction.aggregate([{ $match:{ type:'deposit', status:'completed' } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Transaction.aggregate([{ $match:{ type:'withdrawal', status:'completed' } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Transaction.aggregate([{ $match:{ type:'win' } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Match.countDocuments({ status:'live' }),
      Match.countDocuments({ status:'upcoming', commenceTime:{ $gte: new Date() } }),
      Transaction.find().sort({ createdAt:-1 }).limit(10).lean()
    ]);
    const deposits    = depAgg[0]?.t  || 0;
    const withdrawals = wdAgg[0]?.t   || 0;
    const winsPaid    = wonAgg[0]?.t  || 0;
    res.json({ success:true, users, bets, pending, deposits, withdrawals, revenue: deposits - winsPaid - withdrawals, liveMatches, upcomingMatches, recent });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── REVENUE ──
router.get('/revenue', async (req, res) => {
  try {
    const [depAgg, winAgg, stakeAgg, taxAgg] = await Promise.all([
      Transaction.aggregate([{ $match:{ type:'deposit', status:'completed' } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Transaction.aggregate([{ $match:{ type:'win' } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Transaction.aggregate([{ $match:{ type:'stake' } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Bet.aggregate([{ $match:{ status:'won' } }, { $group:{ _id:null, t:{ $sum:'$tax' } } }])
    ]);
    const gross = depAgg[0]?.t  || 0;
    const paid  = winAgg[0]?.t  || 0;
    const tax   = taxAgg[0]?.t  || 0;
    // Daily breakdown last 7 days
    const days = [];
    for (let i=6; i>=0; i--) {
      const d  = new Date(); d.setDate(d.getDate()-i);
      const d2 = new Date(d); d2.setDate(d2.getDate()+1);
      const r  = await Transaction.aggregate([
        { $match:{ type:'deposit', status:'completed', createdAt:{ $gte:d, $lt:d2 } } },
        { $group:{ _id:null, t:{ $sum:'$amount' } } }
      ]);
      days.push({ l: d.toLocaleDateString('en-KE',{weekday:'short'}), v: r[0]?.t||0 });
    }
    res.json({ success:true, gross, paid, tax, net: gross-paid, daily: days });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── LIVE STATS ──
router.get('/live-stats', async (req, res) => {
  try {
    const now = new Date();
    const hourAgo = new Date(now - 3600000);
    const today   = new Date(now.toDateString());
    const [betsLastHour, depositsToday, pendingWd] = await Promise.all([
      Bet.countDocuments({ createdAt:{ $gte:hourAgo } }),
      Transaction.aggregate([{ $match:{ type:'deposit', status:'completed', createdAt:{ $gte:today } } }, { $group:{ _id:null, t:{ $sum:'$amount' } } }]),
      Transaction.countDocuments({ type:'withdrawal', status:'pending' })
    ]);
    res.json({ success:true, betsLastHour, depositsToday: depositsToday[0]?.t||0, pendingWd });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── USERS ──
router.get('/users', async (req, res) => {
  try {
    // Join real, live Wallet balances instead of reading the stale legacy
    // User.balance field — same bug/fix as GET /user/:id below, but done as
    // a single aggregation here since this returns up to 200 users at once
    // and looping individual wallet lookups would be far too slow.
    const users = await User.aggregate([
      { $sort: { createdAt: -1 } },
      { $limit: 200 },
      { $lookup: { from: 'wallets', localField: '_id', foreignField: 'userId', as: 'wallet' } },
      { $addFields: {
          balance: { $ifNull: [ { $add: [
            { $ifNull: [ { $arrayElemAt: ['$wallet.main', 0] }, 0 ] },
            { $ifNull: [ { $arrayElemAt: ['$wallet.bonus', 0] }, 0 ] }
          ] }, 0 ] }
      } },
      { $project: { username:1, phone:1, balance:1, createdAt:1, isActive:1 } }
    ]);
    res.json({ success:true, data:users });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.get('/user/:id', async (req, res) => {
  try {
    let q = req.params.id.trim();
    let phone = q.replace(/\D/g,'');
    if (phone.startsWith('0')) phone = '254'+phone.slice(1);
    const user = await User.findOne({ $or:[{phone},{username:q.toLowerCase()}] })
      .select('username phone createdAt isActive role kycStatus phoneVerified dailyDepositLimit dailyStakeLimit selfExcludedUntil favouriteTeams')
      .lean();
    if (!user) return res.status(404).json({ success:false, message:'User not found' });
    const bets = await Bet.countDocuments({ userId:user._id });
    // Live wallet balance — NEVER read User.balance for display. That field is
    // a legacy snapshot only ever written to when an admin manually adjusts
    // balance; every normal bet, win, loss, deposit, and withdrawal updates
    // the real Wallet collection only, so User.balance silently goes stale
    // for any user who does anything but get a manual admin adjustment.
    const wallet = await walletService.getBalance(user._id);
    res.json({ success:true, user:{ ...user, balance: wallet.spendable, walletMain: wallet.main, walletBonus: wallet.bonus, walletLocked: wallet.locked, bets } });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.delete('/user/:id', async (req, res) => {
  try {
    let q = req.params.id.trim();
    let phone = q.replace(/\D/g,'');
    if (phone.startsWith('0')) phone = '254'+phone.slice(1);
    const user = await User.findOneAndDelete({ $or:[{phone},{username:q.toLowerCase()}] });
    if (!user) return res.status(404).json({ success:false, message:'User not found' });
    audit('DELETE_USER', { username:user.username, phone:user.phone });
    res.json({ success:true, message:`Deleted: ${user.username}` });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/user/toggle', async (req, res) => {
  try {
    const { userId, active } = req.body;
    const user = await User.findByIdAndUpdate(userId, { $set:{ isActive:active } }, { new:true });
    if (!user) return res.status(404).json({ success:false, message:'User not found' });
    audit('TOGGLE_USER', { username:user.username, active });
    res.json({ success:true, message:`User ${active?'activated':'suspended'}` });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.get('/user/:id/bets', async (req, res) => {
  try {
    const status = req.query.status; // optional filter, e.g. 'pending'
    const q = { userId: req.params.id };
    if (status) q.status = status;
    const bets = await Bet.find(q).sort({ createdAt: -1 }).limit(30).lean();
    res.json({ success:true, data: bets });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── EDIT USER (general profile fields) ──
// Deliberately excludes balance/bonus — those must go through POST /admin/balance,
// which uses walletService + Transaction records instead of a raw $set, and the
// User schema itself blocks a direct $set on balance at the model level (see
// the pre('findOneAndUpdate') hook in models/User.js). This endpoint is only
// for account/profile fields, never the wallet itself.
const EDITABLE_USER_FIELDS = [
  'username', 'phone', 'phoneVerified', 'role', 'isActive',
  'kycStatus', 'kycRejectReason', 'favouriteTeams',
  'dailyDepositLimit', 'dailyStakeLimit', 'selfExcludedUntil'
];
router.patch('/user/:id', async (req, res) => {
  try {
    const updates = {};
    for (const field of EDITABLE_USER_FIELDS) {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) updates[field] = req.body[field];
    }
    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ success:false, message:'No editable fields provided.' });
    }
    if (updates.role && !['user','admin','support'].includes(updates.role)) {
      return res.status(400).json({ success:false, message:'Invalid role.' });
    }

    const before = await User.findById(req.params.id).lean();
    if (!before) return res.status(404).json({ success:false, message:'User not found' });

    const user = await User.findByIdAndUpdate(req.params.id, { $set: updates }, { new:true, runValidators:true });
    audit('EDIT_USER', { userId: req.params.id, username: user.username, changes: updates });
    require('../services/auditService').log('admin.user.edit', { targetType:'User', targetId:req.params.id, meta:{ changes: updates } }).catch(()=>{});
    res.json({ success:true, message:'User updated.', user });
  } catch(e) {
    if (e.code === 11000) return res.status(400).json({ success:false, message:'That username or phone is already in use.' });
    return safeError(res, e, 'admin');
  }
});

// ── RESET USER PASSWORD (admin-initiated, e.g. account recovery) ──
router.post('/user/:id/reset-password', async (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ success:false, message:'New password must be at least 6 characters.' });
    }
    const bcrypt = require('bcryptjs');
    const passwordHash = await bcrypt.hash(newPassword, 10);
    const user = await User.findByIdAndUpdate(req.params.id, { $set:{ passwordHash } }, { new:true });
    if (!user) return res.status(404).json({ success:false, message:'User not found' });
    audit('RESET_USER_PASSWORD', { userId: req.params.id, username: user.username });
    res.json({ success:true, message:`Password reset for ${user.username}.` });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── SEND SMS TO USER ──
router.post('/user/:id/message', async (req, res) => {
  console.log(`[admin/sms] Request received for user ${req.params.id}`);
  try {
    const { message } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ success:false, message:'Message text is required.' });
    }
    if (message.length > 459) { // 3 SMS segments (153 chars each) — CommsGrid concatenates but this is a sane cap
      return res.status(400).json({ success:false, message:'Message too long (max 459 characters).' });
    }
    const user = await User.findById(req.params.id).select('username phone').lean();
    if (!user) return res.status(404).json({ success:false, message:'User not found' });

    console.log(`[admin/sms] Sending to ${user.phone} (${user.username}): "${message.trim().slice(0,40)}..."`);
    const { sendSms } = require('../services/smsService');
    const result = await sendSms(user.phone, message.trim());
    console.log(`[admin/sms] Result:`, JSON.stringify(result));
    if (!result.success) {
      return res.status(502).json({ success:false, message:`SMS failed to send: ${result.error}` });
    }

    audit('SEND_USER_SMS', { userId: req.params.id, username: user.username, messageLength: message.length });
    require('../services/auditService').log('admin.user.message', { targetType:'User', targetId:req.params.id, meta:{ messageLength: message.length } }).catch(()=>{});
    res.json({ success:true, message:`SMS sent to ${user.username} (${user.phone}).` });
  } catch(e) {
    console.error('[admin/sms] Exception:', e.message);
    return safeError(res, e, 'admin');
  }
});

// ── BALANCE ──
router.post('/balance', async (req, res) => {
  try {
    const { identifier, amount, note } = req.body;
    if (!identifier || isNaN(amount)) return res.status(400).json({ success:false, message:'identifier and amount required' });
    let phone = identifier.replace(/\D/g,'');
    if (phone.startsWith('0')) phone = '254'+phone.slice(1);
    const user = await User.findOne({ $or:[{phone},{username:identifier.toLowerCase()}] });
    if (!user) return res.status(404).json({ success:false, message:'User not found' });

    const amt = parseFloat(amount);
    let wallet;
    if (amt >= 0) {
      wallet = await walletService.credit(user._id, 'main', amt, 'admin_adjustment', null, { note, admin: true });
    } else {
      wallet = await walletService.debit(user._id, 'main', Math.abs(amt), 'admin_adjustment', null, { note, admin: true });
      if (!wallet) return res.status(400).json({ success:false, message:'User has insufficient main balance for this deduction' });
    }
    await User.findByIdAndUpdate(user._id, { $inc:{ balance: amt } }).catch(()=>{}); // keep legacy field in sync

    await Transaction.create({ userId:user._id, type:amt>0?'bonus':'withdrawal', amount:amt, balance:wallet.main, description:note||`Admin adjustment KES ${amt}` });
    audit('ADJUST_BALANCE', { username:user.username, amount:amt, note });
    require('../services/auditService').log('admin.balance.adjust', { targetType:'User', targetId:user._id.toString(), meta:{ amount:amt, note } });
    res.json({ success:true, balance:wallet.main });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── BLACKLIST ──
router.get('/blacklist', (req, res) => {
  res.json({ success:true, data:store.blacklist });
});

router.post('/blacklist', async (req, res) => {
  const { target, reason } = req.body;
  if (!target) return res.status(400).json({ success:false, message:'target required' });
  const entry = { _id: Date.now().toString(), target, reason, createdAt: new Date() };
  store.blacklist.unshift(entry);
  await persistBlacklist();
  audit('BLACKLIST_ADD', { target, reason });
  res.json({ success:true, entry });
});

router.delete('/blacklist/:id', async (req, res) => {
  store.blacklist = store.blacklist.filter(b => b._id !== req.params.id);
  await persistBlacklist();
  res.json({ success:true });
});

// ── BETS ──
router.get('/bets', async (req, res) => {
  try {
    const filter = {};
    if (req.query.status && req.query.status !== 'all') filter.status = req.query.status;
    if (req.query.search) filter.betCode = new RegExp(req.query.search, 'i');
    const bets = await Bet.find(filter).sort({ createdAt:-1 }).limit(100)
      .populate('userId', 'username phone').lean();
    res.json({ success:true, data:bets });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/settle', async (req, res) => {
  try {
    const { runSettlement } = require('../engine/settlementEngine');
    const result = await runSettlement();
    audit('SETTLE', result);
    res.json({ success:true, result });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── MATCHES ──
// Admin match list intentionally covers ALL games regardless of source
// (manual, apif, tsdb, oddsapi, footballdata, oddsapiio) and status — unlike the
// public-facing odds routes, the admin needs to find and edit odds on any game,
// including ones a normal user can no longer see (finished / older than the
// public visibility window). Supports optional filters via query params.
router.get('/matches', async (req, res) => {
  try {
    const { status, q, limit } = req.query;
    const filter = {};
    if (status) filter.status = { $in: status.split(',') };
    if (q) {
      const rx = new RegExp(q.trim(), 'i');
      filter.$or = [{ homeTeam: rx }, { awayTeam: rx }, { league: rx }];
    }
    let matches = await Match.find(filter)
      .limit(Math.min(parseInt(limit) || 300, 1000))
      .lean();

    // Order by urgency, not raw date: live games first (need attention right
    // now), then upcoming games soonest-kickoff-first (easiest to prioritize
    // which needs odds added next), then everything else (finished/cancelled)
    // most-recent-first. Sorting all statuses together by one date field
    // (as before) buried soon-to-kickoff matches under far-future ones.
    const rank = (m) => m.status === 'live' ? 0 : m.status === 'upcoming' ? 1 : 2;
    matches.sort((a, b) => {
      const ra = rank(a), rb = rank(b);
      if (ra !== rb) return ra - rb;
      const ta = new Date(a.commenceTime).getTime();
      const tb = new Date(b.commenceTime).getTime();
      return ra === 2 ? tb - ta : ta - tb; // finished/cancelled: most recent first; live/upcoming: soonest first
    });

    res.json({ success:true, data:matches });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/match', async (req, res) => {
  try {
    const { homeTeam, awayTeam, league, commenceTime, sport, customOdds } = req.body;
    if (!homeTeam||!awayTeam||!league||!commenceTime) return res.status(400).json({ success:false, message:'All fields required' });
    const h = s => (s||'').split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    const seed = (h(homeTeam)*7+h(awayTeam)*3)%100;
    const autoOdds = { home:+(1.4+(seed%30)/20).toFixed(2), draw:+(2.8+(seed%20)/15).toFixed(2), away:+(1.7+(seed%35)/18).toFixed(2) };
    const odds = customOdds || autoOdds;
    const match = await Match.create({ matchId:`manual_${Date.now()}`, sport:sport||'soccer_friendlies', league, homeTeam, awayTeam, commenceTime:new Date(commenceTime), status:'upcoming', odds, isStatic:true, source:'manual' });
    audit('ADD_MATCH', { homeTeam, awayTeam, league });
    res.json({ success:true, match });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.delete('/match/:matchId', async (req, res) => {
  try {
    await Match.findOneAndDelete({ matchId:req.params.matchId });
    audit('DELETE_MATCH', { matchId:req.params.matchId });
    res.json({ success:true, message:'Match deleted' });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── ODDS UPDATE ──
// Works for ANY match regardless of source — manual, API-Football (apif_...),
// TheSportsDB (tsdb_...), Odds API (oddsapi_...), football-data.org (fd_...),
// or odds-api.io (oapi_...). Setting oddsLocked:true is what makes this stick:
// every automated sync/poll in server/routes/odds.js and server/engine/apifootball.js
// checks this flag before touching `odds`/`hasOdds`, so a live API refresh will
// never silently overwrite odds an admin has set.
router.post('/odds', async (req, res) => {
  try {
    const { matchId, home, draw, away } = req.body;
    if (!matchId||!home||!draw||!away) return res.status(400).json({ success:false, message:'All fields required' });
    if ([home,draw,away].some(v => !(parseFloat(v) > 1))) {
      return res.status(400).json({ success:false, message:'Odds must be numbers greater than 1' });
    }
    const match = await Match.findOneAndUpdate(
      { matchId },
      { $set:{
        'odds.home':parseFloat(home), 'odds.draw':parseFloat(draw), 'odds.away':parseFloat(away),
        'odds.updatedAt':new Date(),
        hasOdds:true,
        oddsLocked:true,
        oddsLockedAt:new Date(),
        oddsLockedBy: req.headers['x-admin-user'] || 'admin'
      } },
      { new:true }
    );
    if (!match) return res.status(404).json({ success:false, message:'Match not found' });
    audit('UPDATE_ODDS', { matchId, home, draw, away, source: match.source });
    res.json({ success:true, match });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── ODDS UNLOCK ── revert a match to automatic odds from its original API source
// (the next sync/poll will repopulate `odds` normally). Useful if an admin wants
// to stop overriding a game and let live market odds take over again.
router.post('/odds/unlock', async (req, res) => {
  try {
    const { matchId } = req.body;
    if (!matchId) return res.status(400).json({ success:false, message:'matchId required' });
    const match = await Match.findOneAndUpdate(
      { matchId },
      { $set:{ oddsLocked:false, oddsLockedAt:null, oddsLockedBy:null } },
      { new:true }
    );
    if (!match) return res.status(404).json({ success:false, message:'Match not found' });
    audit('UNLOCK_ODDS', { matchId });
    res.json({ success:true, match });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── TRANSACTIONS ──
router.get('/transactions', async (req, res) => {
  try {
    const filter = {};
    if (req.query.type && req.query.type !== 'all') filter.type = req.query.type;
    if (req.query.status) filter.status = req.query.status;
    const txs = await Transaction.find(filter).sort({ createdAt:-1 }).limit(200).lean();
    res.json({ success:true, data:txs });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── WITHDRAWAL APPROVE/REJECT ──
router.post('/withdrawal/approve', async (req, res) => {
  try {
    const { txId } = req.body;

    // Atomically claim this transaction by flipping pending -> processing in one
    // step. If two clicks (or a double-tap) hit this at the same time, only the
    // first one will find status:'pending' and succeed; the second will match
    // nothing and get a clear "already being processed" response — never a
    // second real B2C send for the same withdrawal.
    const tx = await Transaction.findOneAndUpdate(
      { _id: txId, status: 'pending' },
      { $set: { status: 'processing' } },
      { new: false } // return the pre-update doc so we still have original fields
    );
    if (!tx) {
      const existing = await Transaction.findById(txId).lean();
      if (!existing) return res.status(404).json({ success:false, message:'Transaction not found' });
      return res.status(409).json({ success:false, message:`Already ${existing.status} — cannot approve again.` });
    }

    // Extract the recipient phone number from the transaction description
    // (format: "Withdrawal KES <amount> to <phone>") since it isn't stored as its own field.
    const phoneMatch = tx.description?.match(/to (\d+)/);
    const phone = phoneMatch?.[1];
    if (!phone) {
      await Transaction.findByIdAndUpdate(txId, { $set: { status: 'pending' } }); // release the lock, nothing was sent
      return res.status(400).json({ success:false, message:'Could not determine recipient phone number from transaction — approve manually only after confirming payment was actually sent via M-Pesa.' });
    }

    // Actually attempt to send the money via B2C — approving in the dashboard
    // must not silently mark "completed" without a real disbursement attempt.
    const { sendB2C } = require('./withdraw');
    let b2cResult;
    try {
      b2cResult = await sendB2C(phone, Math.abs(tx.amount), tx.reference);
    } catch (b2cErr) {
      const detail = b2cErr?.response?.data ? JSON.stringify(b2cErr.response.data) : b2cErr.message;
      console.error('[admin/withdrawal/approve] B2C send failed:', detail);
      // Send genuinely failed — release the lock back to pending so it can be retried.
      await Transaction.findByIdAndUpdate(txId, { $set: { status: 'pending' } });
      return res.status(502).json({ success:false, message: `B2C send failed — money was NOT sent: ${detail}` });
    }

    if (b2cResult?.ResponseCode !== '0') {
      await Transaction.findByIdAndUpdate(txId, { $set: { status: 'pending' } });
      return res.status(502).json({ success:false, message: `Safaricom did not accept the request: ${JSON.stringify(b2cResult)}` });
    }

    // B2C was accepted by Safaricom — leave status as 'processing' (NOT pending,
    // so it can never be double-approved, and NOT completed, since only the real
    // /b2c/result callback should do that once Safaricom confirms the payout).
    await Transaction.findByIdAndUpdate(txId, {
      $set: {
        description: `${tx.description} — B2C sent via admin approve: ${b2cResult.ConversationID}`,
        conversationId: b2cResult.ConversationID
      }
    });

    audit('APPROVE_WITHDRAWAL', { txId, amount: tx.amount });
    require('../services/auditService').log('admin.withdrawal.approve', { targetType:'Transaction', targetId:txId, meta:{ amount: tx.amount } });
    res.json({ success:true, message:'B2C payout sent to Safaricom — awaiting confirmation callback. Do not mark as completed manually.' });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/withdrawal/reject', async (req, res) => {
  try {
    const { txId, reason } = req.body;
    const tx = await Transaction.findById(txId);
    if (!tx) return res.status(404).json({ success:false, message:'Transaction not found' });
    if (tx.status !== 'pending') return res.status(400).json({ success:false, message:'Transaction is not pending' });

    const amount = Math.abs(tx.amount);
    // Release funds from locked back to main (this withdrawal was locked, not yet debited from main permanently)
    await walletService.releaseLock(tx.userId, amount, tx.reference);
    await User.findByIdAndUpdate(tx.userId, { $inc:{ balance: amount } }).catch(()=>{});

    await Transaction.findByIdAndUpdate(txId, { $set:{ status:'failed', description:(tx.description||'')+ ' — Rejected: '+(reason||'Admin') } });
    await Transaction.create({ userId:tx.userId, type:'refund', amount, balance:(await walletService.getBalance(tx.userId)).main, description:`Withdrawal rejected: ${reason||'Admin'}` });

    require('../services/notificationService').notify(tx.userId, 'withdrawal_failed', { amount }).catch(()=>{});
    audit('REJECT_WITHDRAWAL', { txId, reason });
    require('../services/auditService').log('admin.withdrawal.reject', { targetType:'Transaction', targetId:txId, meta:{ reason, amount } });
    res.json({ success:true, message:'Rejected and refunded' });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── WALLET ──
router.get('/wallet', async (req, res) => {
  try {
    // Real, live balances only — same fix as GET /users and GET /user/:id
    // above. User.balance is a frozen legacy field; the Wallet collection is
    // the only accurate source after any bet, deposit, win, or loss.
    const pipeline = [
      { $lookup: { from: 'wallets', localField: '_id', foreignField: 'userId', as: 'wallet' } },
      { $addFields: {
          balance: { $ifNull: [ { $add: [
            { $ifNull: [ { $arrayElemAt: ['$wallet.main', 0] }, 0 ] },
            { $ifNull: [ { $arrayElemAt: ['$wallet.bonus', 0] }, 0 ] }
          ] }, 0 ] }
      } }
    ];
    const agg = await User.aggregate([
      ...pipeline,
      { $group:{ _id:null, total:{ $sum:'$balance' }, count:{ $sum:{ $cond:[{ $gt:['$balance',0] },1,0] } } } }
    ]);
    const top = await User.aggregate([
      ...pipeline,
      { $match: { balance: { $gt: 0 } } },
      { $sort: { balance: -1 } },
      { $limit: 20 },
      { $project: { username:1, phone:1, balance:1 } }
    ]);
    res.json({ success:true, totalBalance:agg[0]?.total||0, fundedUsers:agg[0]?.count||0, topWallets:top });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── LIMITS ──
router.get('/limits', async (req, res) => {
  res.json({ success:true, data: store.limits });
});
router.post('/limits', async (req, res) => {
  const { type, ...data } = req.body;
  Object.assign(store.limits, data);
  await persistLimits();
  audit('UPDATE_LIMITS', { type, ...data });
  res.json({ success:true });
});

// ── LIVE ODDS RISK CONFIG ──
// See store.liveRisk above and server/services/marketResolver.js for how this
// is actually enforced (on both the odds display API and bet placement).
router.get('/live-risk', async (req, res) => {
  res.json({ success: true, data: store.liveRisk });
});
router.post('/live-risk', async (req, res) => {
  const data = req.body || {};
  // Basic shape validation — this directly controls real-money risk exposure,
  // so a malformed save (e.g. a missing rules array from a buggy client) must
  // be rejected outright rather than partially applied.
  if (data.rules !== undefined) {
    if (!Array.isArray(data.rules)) return res.status(400).json({ success: false, message: 'rules must be an array' });
    for (const r of data.rules) {
      if (typeof r.minMinute !== 'number' || r.minMinute < 0 || r.minMinute > 120) return res.status(400).json({ success: false, message: `Invalid minMinute in rule ${r.id || '?'}` });
      if (typeof r.minGoalDiff !== 'number' || r.minGoalDiff < 1 || r.minGoalDiff > 10) return res.status(400).json({ success: false, message: `Invalid minGoalDiff in rule ${r.id || '?'}` });
      if (!['suspend_leading', 'suspend_market'].includes(r.action)) return res.status(400).json({ success: false, message: `Invalid action in rule ${r.id || '?'}` });
    }
  }
  if (data.affectedMarkets !== undefined && !Array.isArray(data.affectedMarkets)) {
    return res.status(400).json({ success: false, message: 'affectedMarkets must be an array' });
  }
  for (const numField of ['dataFreshnessMaxAgeSec', 'goalEventSuspensionSec', 'drawSuspendMinutesRemaining', 'minAcceptableOdds']) {
    if (data[numField] !== undefined && (typeof data[numField] !== 'number' || data[numField] < 0)) {
      return res.status(400).json({ success: false, message: `Invalid ${numField}` });
    }
  }
  Object.assign(store.liveRisk, data);
  await persistLiveRisk();
  audit('UPDATE_LIVE_RISK', data);
  res.json({ success: true, data: store.liveRisk });
});

// ── BONUS SETTINGS ──
// The welcome bonus a new user actually receives is granted by
// promotionService.tryGrantWelcomeBonus() on their first deposit, which looks
// up a Promotion document with type:'welcome_bonus'. Previously this admin
// panel only saved to a disconnected in-memory settings store that nothing
// in the real deposit flow ever read — meaning saved changes here silently
// never took effect for real users. This now upserts the actual Promotion
// record that's checked at deposit time.
router.get('/bonus-settings', async (req, res) => {
  try {
    const promo = await Promotion.findOne({ type: 'welcome_bonus' }).lean();
    res.json({ success:true, data: {
      welcomeBonus: promo?.amountValue ?? store.bonusSettings.welcomeBonus,
      minBonusDep:  promo?.minDeposit  ?? store.bonusSettings.minBonusDep,
      active: promo?.active ?? true
    }});
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/bonus-settings', async (req, res) => {
  try {
    const { welcomeBonus, minBonusDep } = req.body;
    if (welcomeBonus === undefined || welcomeBonus < 0) {
      return res.status(400).json({ success:false, message:'Welcome bonus amount is required and must be 0 or more.' });
    }

    // This is the fix — actually write to the Promotion collection the
    // deposit flow depends on, not just the disconnected settings store.
    await Promotion.findOneAndUpdate(
      { type: 'welcome_bonus' },
      {
        $set: {
          name: 'Welcome Bonus',
          type: 'welcome_bonus',
          amountType: 'fixed',
          amountValue: welcomeBonus,
          minDeposit: minBonusDep || 0,
          active: true
        }
      },
      { upsert: true, new: true }
    );

    // Keep the legacy store in sync too, in case anything else still reads it
    Object.assign(store.bonusSettings, req.body);
    await persistBonusSettings();

    audit('UPDATE_BONUS', req.body);
    res.json({ success:true, message:'Welcome bonus updated — takes effect on the next qualifying deposit.' });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── NOTIFICATIONS ──
// Clear 2FA for a user who's locked out — necessary safety valve now that
// self-service 2FA setup/disable UI has been removed from the account page.
router.post('/2fa/reset', async (req, res) => {
  try {
    const { identifier } = req.body;
    if (!identifier) return res.status(400).json({ success:false, message:'identifier required' });
    let phone = identifier.replace(/\D/g,'');
    if (phone.startsWith('0')) phone = '254'+phone.slice(1);
    const user = await User.findOne({ $or:[{phone},{username:identifier.toLowerCase()}] });
    if (!user) return res.status(404).json({ success:false, message:'User not found' });

    await User.findByIdAndUpdate(user._id, {
      $set: { twoFactorEnabled: false },
      $unset: { twoFactorSecret: 1, twoFactorBackupCodes: 1 }
    });
    audit('2FA_RESET', { username: user.username });
    require('../services/auditService').log('admin.2fa.reset', { targetType:'User', targetId:user._id.toString() });
    res.json({ success:true, message:`2FA cleared for ${user.username}` });
  } catch(e) { return safeError(res, e, 'admin/2fa-reset'); }
});

router.post('/notify', async (req, res) => {
  try {
    const { title, message, target } = req.body;
    if (!title||!message) return res.status(400).json({ success:false, message:'title and message required' });
    let users = [];
    if (target === 'all') users = await User.find().select('_id').lean();
    else if (target === 'active') {
      const activeBettors = await Bet.distinct('userId', { createdAt:{ $gte: new Date(Date.now()-30*86400000) } });
      users = activeBettors.map(id => ({ _id: id }));
    } else {
      const activeBettors = await Bet.distinct('userId');
      const allUsers = await User.find().select('_id').lean();
      const activeSet = new Set(activeBettors.map(String));
      users = allUsers.filter(u => !activeSet.has(String(u._id)));
    }

    // Actually create + push the notification to every targeted user.
    // Bulk-insert into Mongo for speed (this.notify() per-user would be too slow
    // for large user lists and could time out the admin request), then push a
    // live WebSocket event to whoever's currently online.
    const Notification = require('../models/Notification');
    const now = new Date();
    const docs = users.map(u => ({ userId: u._id, type: 'system', title, message, data: {}, read: false, createdAt: now, updatedAt: now }));
    let inserted = [];
    if (docs.length) inserted = await Notification.insertMany(docs);

    const notificationService = require('../services/notificationService');
    const wsBroadcast = notificationService.getBroadcaster && notificationService.getBroadcaster();
    if (wsBroadcast) {
      for (const doc of inserted) {
        try { wsBroadcast(doc.userId.toString(), doc); } catch (_) {}
      }
    }

    store.notifications.unshift({ title, message, target, sent: users.length, createdAt: new Date() });
    audit('BROADCAST', { title, sent: users.length });
    res.json({ success:true, sent: users.length });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── CONTENT ──
// ── IMAGE UPLOAD (banner, etc.) — stored directly in MongoDB, no third-party service needed ──
const multer = require('multer');
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 4 * 1024 * 1024 }, // 4MB cap — keeps documents well under Mongo's 16MB limit and pages fast
  fileFilter: (req, file, cb) => {
    if (!/^image\/(png|jpe?g|webp|gif)$/.test(file.mimetype)) {
      return cb(new Error('Only PNG, JPG, WEBP or GIF images are allowed'));
    }
    cb(null, true);
  }
});
router.post('/upload-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No image file received' });
    const key = (req.body.key || 'banner').toString().slice(0, 50);
    const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;

    const SiteImage = require('../models/SiteImage');
    await SiteImage.findOneAndUpdate(
      { key },
      { key, dataUrl, mimeType: req.file.mimetype, sizeBytes: req.file.size, uploadedAt: new Date() },
      { upsert: true }
    );

    // Point content at the new served URL for whichever key this upload is for
    const url = `/api/content/image/${key}?v=${Date.now()}`;
    if (key === 'banner') store.content.bannerImage = url;
    if (key === 'popup') { store.content.popupImage = url; store.content.popupEnabled = true; }
    await persistContent();

    audit('UPLOAD_IMAGE', { key, sizeBytes: req.file.size });
    res.json({ success: true, url });
  } catch (e) {
    if (e.message && e.message.includes('File too large')) {
      return res.status(400).json({ success: false, message: 'Image too large — max 4MB' });
    }
    return safeError(res, e, 'admin/upload-image', 400, e.message && e.message.includes('allowed') ? e.message : 'Upload failed');
  }
});

// ── MULTI-BANNER CAROUSEL ──
// A Betika-style homepage strip the visitor can swipe/click through, rather
// than the single static banner above. Each banner is its own SiteImage
// document (own unique key) so they can be added/removed independently
// without disturbing the others, and reordered without re-uploading anything.
router.post('/banners', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No image file received' });
    const key = `banner_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;

    const SiteImage = require('../models/SiteImage');
    await SiteImage.create({ key, dataUrl, mimeType: req.file.mimetype, sizeBytes: req.file.size, uploadedAt: new Date() });

    const link = (req.body.link || '').toString().trim().slice(0, 500);
    const url = `/api/content/image/${key}`;
    if (!Array.isArray(store.content.banners)) store.content.banners = [];
    store.content.banners.push({ key, image: url, link });
    await persistContent();

    audit('ADD_BANNER', { key, sizeBytes: req.file.size, link });
    res.json({ success: true, banners: store.content.banners });
  } catch (e) {
    if (e.message && e.message.includes('File too large')) {
      return res.status(400).json({ success: false, message: 'Image too large — max 4MB' });
    }
    return safeError(res, e, 'admin/banners', 400, e.message && e.message.includes('allowed') ? e.message : 'Upload failed');
  }
});

router.delete('/banners/:key', async (req, res) => {
  try {
    const key = req.params.key;
    if (!Array.isArray(store.content.banners)) store.content.banners = [];
    const before = store.content.banners.length;
    store.content.banners = store.content.banners.filter(b => b.key !== key);
    if (store.content.banners.length === before) return res.status(404).json({ success: false, message: 'Banner not found' });
    await persistContent();
    require('../models/SiteImage').deleteOne({ key }).catch(() => {}); // best-effort cleanup of the underlying image doc
    audit('DELETE_BANNER', { key });
    res.json({ success: true, banners: store.content.banners });
  } catch (e) { return safeError(res, e, 'admin/banners-delete'); }
});

router.post('/banners/reorder', async (req, res) => {
  try {
    const { keys } = req.body;
    if (!Array.isArray(keys)) return res.status(400).json({ success: false, message: 'keys must be an array' });
    const current = Array.isArray(store.content.banners) ? store.content.banners : [];
    const map = new Map(current.map(b => [b.key, b]));
    const reordered = keys.map(k => map.get(k)).filter(Boolean);
    if (reordered.length !== current.length) return res.status(400).json({ success: false, message: 'keys do not match the current banner set' });
    store.content.banners = reordered;
    await persistContent();
    audit('REORDER_BANNERS', { keys });
    res.json({ success: true, banners: store.content.banners });
  } catch (e) { return safeError(res, e, 'admin/banners-reorder'); }
});

// ── APK UPLOAD ── (separate, larger limit + GridFS since APKs run 5-80MB+)
const uploadApk = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 150 * 1024 * 1024 }, // 150MB cap — generous for a betting app APK
  fileFilter: (req, file, cb) => {
    const name = (file.originalname || '').toLowerCase();
    if (!name.endsWith('.apk')) return cb(new Error('Only .apk files are allowed'));
    cb(null, true);
  }
});
router.post('/upload-apk', uploadApk.single('apk'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No APK file received' });
    const version = (req.body.version || '').toString().slice(0, 30);

    const apkStorage = require('../utils/apkStorage');
    await apkStorage.replaceApk(req.file.buffer, req.file.originalname, { version });

    audit('UPLOAD_APK', { filename: req.file.originalname, sizeBytes: req.file.size, version });
    res.json({ success: true, message: 'APK uploaded — live for download now', sizeBytes: req.file.size });
  } catch (e) {
    if (e.message && e.message.includes('File too large')) {
      return res.status(400).json({ success: false, message: 'APK too large — max 150MB' });
    }
    return safeError(res, e, 'admin/upload-apk', 400, e.message && e.message.includes('allowed') ? e.message : 'Upload failed');
  }
});

router.get('/apk-info', async (req, res) => {
  try {
    const apkStorage = require('../utils/apkStorage');
    const info = await apkStorage.getApkInfo();
    res.json({ success: true, data: info });
  } catch (e) {
    return safeError(res, e, 'admin/apk-info');
  }
});

// ── ODDS BOOST ──
router.post('/odds-boost', async (req, res) => {
  try {
    const { matchId, market, pick, boostedOdds, maxQualifyingStake, expiresAt } = req.body;
    if (!matchId || !market || !pick || !boostedOdds || !maxQualifyingStake) {
      return res.status(400).json({ success: false, message: 'matchId, market, pick, boostedOdds, and maxQualifyingStake are all required' });
    }
    if (boostedOdds < 1.01 || boostedOdds > 1000) return res.status(400).json({ success: false, message: 'Invalid boosted odds' });
    if (maxQualifyingStake <= 0 || maxQualifyingStake > 500000) return res.status(400).json({ success: false, message: 'Invalid max qualifying stake' });

    // Confirm the real odds so the admin can see the exposure before publishing
    const match = await Match.findOne({ matchId }).lean();
    if (!match) return res.status(404).json({ success: false, message: 'Match not found' });
    const { resolveOdds } = require('../services/marketResolver');
    const real = resolveOdds(match, market, pick);
    if (!real) return res.status(400).json({ success: false, message: 'No real odds available for this market/pick to boost from' });
    if (boostedOdds <= real.odds) return res.status(400).json({ success: false, message: `Boosted odds (${boostedOdds}) must be higher than the real odds (${real.odds}) — otherwise it isn't a boost` });

    const maxLoss = parseFloat((maxQualifyingStake * (boostedOdds - real.odds)).toFixed(2));

    const OddsBoost = require('../models/OddsBoost');
    const boost = await OddsBoost.create({
      matchId, market, pick, boostedOdds, maxQualifyingStake,
      expiresAt: expiresAt || null, createdBy: 'admin'
    });
    audit('CREATE_ODDS_BOOST', { matchId, market, pick, boostedOdds, maxQualifyingStake, maxLoss });
    res.json({ success: true, boost, realOdds: real.odds, maxPossibleLoss: maxLoss });
  } catch (e) { return safeError(res, e, 'admin/odds-boost'); }
});

router.get('/odds-boost', async (req, res) => {
  try {
    const OddsBoost = require('../models/OddsBoost');
    const boosts = await OddsBoost.find().sort({ createdAt: -1 }).limit(50).lean();
    res.json({ success: true, data: boosts });
  } catch (e) { return safeError(res, e, 'admin/odds-boost'); }
});

router.post('/odds-boost/:id/toggle', async (req, res) => {
  try {
    const OddsBoost = require('../models/OddsBoost');
    const boost = await OddsBoost.findById(req.params.id);
    if (!boost) return res.status(404).json({ success: false, message: 'Boost not found' });
    boost.active = !boost.active;
    await boost.save();
    audit('TOGGLE_ODDS_BOOST', { id: boost._id, active: boost.active });
    res.json({ success: true, active: boost.active });
  } catch (e) { return safeError(res, e, 'admin/odds-boost'); }
});

router.post('/content', async (req, res) => {
  const { key, value, link, image } = req.body;
  if (key === 'banner') {
    store.content.banner = value;
    store.content.bannerLink = link||'';
    if (typeof image === 'string' && image.length > 0) store.content.bannerImage = image;
  }
  if (key === 'notice') store.content.notice = value;
  if (key === 'popup') {
    store.content.popupLink = link||'';
  }
  await persistContent();
  audit('UPDATE_CONTENT', { key });
  res.json({ success:true });
});

// Toggle the popup ad on/off without needing to re-upload the image
router.post('/content/popup-toggle', async (req, res) => {
  store.content.popupEnabled = !!req.body.enabled;
  await persistContent();
  audit('TOGGLE_POPUP', { enabled: store.content.popupEnabled });
  res.json({ success: true, enabled: store.content.popupEnabled });
});

router.get('/content', (req, res) => res.json({ success:true, data:store.content }));

// ── FRAUD DETECTION ──
router.get('/fraud', async (req, res) => {
  try {
    const patterns = [];
    // Multiple accounts same IP — check for users with same balance amounts
    const dupBets = await Bet.aggregate([
      { $group:{ _id:{ userId:'$userId', matchId:{ $arrayElemAt:['$selections.matchId',0] } }, count:{ $sum:1 } } },
      { $match:{ count:{ $gt:3 } } }
    ]);
    for (const d of dupBets.slice(0,5)) {
      const user = await User.findById(d._id.userId).select('username').lean();
      if (user) patterns.push({ type:'Repeated same bet', description:`${user.username} placed ${d.count} bets on same match`, userId:d._id.userId, username:user.username });
    }
    // Large single bets
    const largeBets = await Bet.find({ stake:{ $gt:50000 }, status:'pending' }).sort({ stake:-1 }).limit(5).lean();
    for (const b of largeBets) {
      const user = await User.findById(b.userId).select('username').lean();
      if (user) patterns.push({ type:'Large bet pending', description:`${user.username} has KES ${b.stake} pending bet`, userId:b.userId, username:user.username });
    }
    const totalUsers = await User.countDocuments();
    res.json({ success:true, patterns, totalUsers });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── LOGIN ACTIVITY ──
router.get('/login-activity', (req, res) => {
  res.json({ success:true, data: store.loginLog.slice(0,100) });
});

// Called by auth route on login
router.logLogin = (userId, username, ip, success) => {
  store.loginLog.unshift({ userId, username, ip, success, createdAt: new Date() });
  if (store.loginLog.length > 1000) store.loginLog.pop();
};

// ── AUDIT LOGS ──
router.get('/audit', (req, res) => {
  res.json({ success:true, data: store.auditLog.slice(0,100) });
});

// ── SITE SETTINGS ──
router.post('/site-settings', async (req, res) => {
  Object.assign(store.settings, req.body);
  await persistSettings();
  audit('UPDATE_SETTINGS', req.body);
  res.json({ success:true });
});

router.get('/site-settings', (req, res) => {
  res.json({ success:true, data: store.settings });
});

// ── REPORT ──
router.get('/report', async (req, res) => {
  try {
    const { type, from, to } = req.query;
    const dateFilter = {};
    if (from) dateFilter.$gte = new Date(from);
    if (to) { const t = new Date(to); t.setDate(t.getDate()+1); dateFilter.$lt = t; }
    const filter = Object.keys(dateFilter).length ? { createdAt: dateFilter } : {};

    let data = {};
    if (type === 'daily' || type === 'revenue') {
      const [dep, wd, win] = await Promise.all([
        Transaction.aggregate([{ $match:{ ...filter, type:'deposit', status:'completed' } }, { $group:{ _id:null, total:{ $sum:'$amount' }, count:{ $sum:1 } } }]),
        Transaction.aggregate([{ $match:{ ...filter, type:'withdrawal', status:'completed' } }, { $group:{ _id:null, total:{ $sum:'$amount' }, count:{ $sum:1 } } }]),
        Transaction.aggregate([{ $match:{ ...filter, type:'win' } }, { $group:{ _id:null, total:{ $sum:'$amount' }, count:{ $sum:1 } } }])
      ]);
      data = { deposits:{ total:dep[0]?.total||0, count:dep[0]?.count||0 }, withdrawals:{ total:wd[0]?.total||0, count:wd[0]?.count||0 }, winnings:{ total:win[0]?.total||0, count:win[0]?.count||0 }, net:(dep[0]?.total||0)-(win[0]?.total||0)-(wd[0]?.total||0) };
    } else if (type === 'users') {
      data.totalUsers    = await User.countDocuments(filter);
      data.activeUsers   = await User.countDocuments({ ...filter, isActive:true });
      data.suspendedUsers= await User.countDocuments({ ...filter, isActive:false });
    } else if (type === 'bets') {
      const [all, won, lost, pend] = await Promise.all([
        Bet.countDocuments(filter), Bet.countDocuments({ ...filter, status:'won' }),
        Bet.countDocuments({ ...filter, status:'lost' }), Bet.countDocuments({ ...filter, status:'pending' })
      ]);
      data = { total:all, won, lost, pending:pend, winRate:all?((won/all)*100).toFixed(1)+'%':'0%' };
    }
    res.json({ success:true, data });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── EXPORT ──
router.get('/export/:type', async (req, res) => {
  try {
    let data;
    if (req.params.type === 'users') data = await User.find().select('-passwordHash').lean();
    else if (req.params.type === 'bets') data = await Bet.find().lean();
    else return res.status(400).json({ success:false, message:'Unknown export type' });
    res.json({ success:true, data, exportedAt: new Date().toISOString(), count: data.length });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── TEST STK ──
router.post('/test-stk', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ success:false, message:'phone required' });
    const mpesaKey    = process.env.MPESA_CONSUMER_KEY;
    const mpesaSec    = process.env.MPESA_CONSUMER_SECRET;
    if (!mpesaKey || !mpesaSec) return res.status(503).json({ success:false, message:'M-Pesa keys not configured in Render environment' });
    res.json({ success:true, message:`Test STK would be sent to ${phone}` });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── CLEAN FAKE MATCHES ──
router.post('/clean-matches', async (req, res) => {
  try {
    const Match = require('../models/Match');
    const del = await Match.deleteMany({
      $or: [
        { source: 'static' },
        { source: 'manual' },
        { matchId: { $regex: /^static_/ } },
        { isStatic: true }
      ]
    });
    // Trigger a fresh sync from Juan Football API
    const { syncFixtures } = require('../engine/apifootball');
    syncFixtures().catch(console.error);
    res.json({ success:true, message:`Deleted ${del.deletedCount} fake matches. Syncing real data...` });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── FIX INDEXES ──
router.post('/fix-indexes', async (req, res) => {
  try {
    await User.collection.dropIndexes();
    await User.syncIndexes();
    const bad = await User.deleteMany({ $or:[{ username:{ $in:[null,''] } },{ phone:{ $in:[null,''] } }] });
    audit('FIX_INDEXES', { deletedBadRecords: bad.deletedCount });
    res.json({ success:true, message:'Indexes rebuilt successfully', deletedBadRecords: bad.deletedCount });
  } catch(e) { res.status(500).json({ success:false, message:'Failed: '+e.message }); }
});

// ── WALLET MANAGEMENT (full bucket view) ──
router.get('/wallets', async (req, res) => {
  try {
    const Wallet = require('../models/Wallet');
    const { page = 1, limit = 50, search } = req.query;
    let userFilter = {};
    if (search) {
      let phone = search.replace(/\D/g,''); if (phone.startsWith('0')) phone = '254'+phone.slice(1);
      userFilter = { $or: [{ phone }, { username: new RegExp(search, 'i') }] };
    }
    const users = search ? await User.find(userFilter).select('_id').lean() : null;
    const filter = users ? { userId: { $in: users.map(u=>u._id) } } : {};
    const skip = (parseInt(page)-1) * limit;
    const [wallets, total] = await Promise.all([
      Wallet.find(filter).populate('userId', 'username phone').sort({ main: -1 }).skip(skip).limit(parseInt(limit)).lean(),
      Wallet.countDocuments(filter)
    ]);
    res.json({ success:true, data: wallets, total, page: parseInt(page), pages: Math.ceil(total/limit) });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.get('/wallets/:userId/history', async (req, res) => {
  try {
    const result = await walletService.getHistory(req.params.userId, { page: parseInt(req.query.page)||1, limit: 50 });
    res.json({ success:true, ...result });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── PROMOTION MANAGEMENT ──
router.get('/promotions', async (req, res) => {
  try {
    const Promotion = require('../models/Promotion');
    const promos = await Promotion.find().sort({ createdAt:-1 }).lean();
    res.json({ success:true, data: promos });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/promotions', async (req, res) => {
  try {
    const Promotion = require('../models/Promotion');
    const promo = await Promotion.create(req.body);
    audit('CREATE_PROMOTION', { name: promo.name, type: promo.type });
    require('../services/auditService').log('admin.promotion.create', { targetType:'Promotion', targetId:promo._id.toString() });
    res.json({ success:true, data: promo });
  } catch(e) { return safeError(res, e, 'admin', 400); }
});

router.patch('/promotions/:id', async (req, res) => {
  try {
    const Promotion = require('../models/Promotion');
    const promo = await Promotion.findByIdAndUpdate(req.params.id, { $set: req.body }, { new:true });
    if (!promo) return res.status(404).json({ success:false, message:'Promotion not found' });
    audit('UPDATE_PROMOTION', { id: req.params.id });
    res.json({ success:true, data: promo });
  } catch(e) { return safeError(res, e, 'admin', 400); }
});

router.delete('/promotions/:id', async (req, res) => {
  try {
    const Promotion = require('../models/Promotion');
    await Promotion.findByIdAndDelete(req.params.id);
    audit('DELETE_PROMOTION', { id: req.params.id });
    res.json({ success:true });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── SITE CONFIG (contact, social, legal content) ──
router.get('/site-config', async (req, res) => {
  try {
    const s = require('../models/Settings');
    const { SITE_DEFAULTS } = require('../routes/settings');
    const cfg = await s.getAll();
    const data = {};
    for (const [k, def] of Object.entries(SITE_DEFAULTS)) {
      data[k] = (cfg[k] !== undefined && cfg[k] !== null) ? cfg[k] : def;
    }
    res.json({ success: true, data });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/site-config', async (req, res) => {
  try {
    const s = require('../models/Settings');
    const allowed = ['site_name','site_email','site_phone','site_whatsapp','site_license',
      'social_twitter','social_facebook','social_instagram','social_telegram','social_whatsapp','social_tiktok',
      'terms_content','privacy_content','responsible_content','faq_items'];
    for (const key of allowed) {
      if (req.body[key] !== undefined) await s.set(key, req.body[key]);
    }
    audit('UPDATE_SITE_CONFIG', { keys: Object.keys(req.body) });
    res.json({ success: true, message: 'Site config updated — live on site immediately' });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── FORCE SETTLE (unstick pending bets immediately) ──
router.post('/force-settle', async (req, res) => {
  try {
    const { runSettlement } = require('../engine/settlementEngine');
    const result = await runSettlement();
    audit('FORCE_SETTLE', result);
    res.json({ success: true, message: `Settlement complete — ${result.settled} bets settled, ${result.paid} paid`, data: result });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── REFERRAL CONFIG (admin can set amount or disable entirely) ──
router.get('/referral/config', async (req, res) => {
  try {
    const cfg = await require('../models/Settings').getAll();
    res.json({
      success: true,
      data: {
        enabled: cfg.referral_enabled !== false,
        amount:  Number(cfg.referral_amount) || 0
      }
    });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/referral/config', async (req, res) => {
  try {
    const { enabled, amount } = req.body;
    const s = require('../models/Settings');
    if (enabled !== undefined) await s.set('referral_enabled', Boolean(enabled));
    if (amount  !== undefined) {
      const n = parseFloat(amount);
      if (isNaN(n) || n < 0) return res.status(400).json({ success:false, message:'Amount must be a positive number or 0' });
      await s.set('referral_amount', n);
    }
    audit('UPDATE_REFERRAL_CONFIG', { enabled, amount });
    const updated = await s.getAll();
    res.json({ success:true, message:'Referral config updated', data: { enabled: updated.referral_enabled, amount: updated.referral_amount } });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── REFERRAL MANAGEMENT ──
router.get('/referrals', async (req, res) => {
  try {
    const topReferrers = await User.aggregate([
      { $match: { referredBy: { $ne: null } } },
      { $group: { _id: '$referredBy', count: { $sum: 1 } } },
      { $sort: { count: -1 } }, { $limit: 20 },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'referrer' } },
      { $unwind: '$referrer' },
      { $project: { username: '$referrer.username', phone: '$referrer.phone', referralCode: '$referrer.referralCode', count: 1 } }
    ]);
    const totalReferred = await User.countDocuments({ referredBy: { $ne: null } });
    res.json({ success:true, data: topReferrers, totalReferred });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── AFFILIATE MANAGEMENT (basic — treats top referrers as affiliates; extend with dedicated model if formal affiliate program is needed) ──
router.get('/affiliates', async (req, res) => {
  try {
    const affiliates = await User.aggregate([
      { $match: { referredBy: { $ne: null } } },
      { $group: { _id: '$referredBy', referredCount: { $sum: 1 } } },
      { $match: { referredCount: { $gte: 3 } } }, // threshold to be considered an "affiliate" tier referrer
      { $sort: { referredCount: -1 } },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
      { $unwind: '$user' },
      { $project: { username: '$user.username', phone: '$user.phone', referralCode: '$user.referralCode', referredCount: 1 } }
    ]);
    res.json({ success:true, data: affiliates });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── ROLES & PERMISSIONS ──
router.get('/roles', async (req, res) => {
  try {
    const counts = await User.aggregate([{ $group: { _id: '$role', count: { $sum: 1 } } }]);
    res.json({ success:true, data: counts, availableRoles: ['user', 'admin', 'support'] });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/roles/set', async (req, res) => {
  try {
    const { userId, role } = req.body;
    if (!['user','admin','support'].includes(role)) return res.status(400).json({ success:false, message:'Invalid role' });
    const user = await User.findByIdAndUpdate(userId, { $set:{ role } }, { new:true }).select('username role');
    if (!user) return res.status(404).json({ success:false, message:'User not found' });
    audit('SET_ROLE', { username: user.username, role });
    require('../services/auditService').log('admin.role.set', { targetType:'User', targetId:userId, meta:{ role } });
    res.json({ success:true, data: user });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── REAL AUDIT LOGS (DB-backed, persists across restarts — complements the in-memory quick log above) ──
router.get('/audit-logs', async (req, res) => {
  try {
    const auditService = require('../services/auditService');
    const result = await auditService.query({ action: req.query.action, page: parseInt(req.query.page)||1, limit: 50 });
    res.json({ success:true, ...result });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── KYC REVIEW QUEUE ──
router.get('/kyc/pending', async (req, res) => {
  try {
    const users = await User.find({ kycStatus: 'pending' }).select('username phone kycDocType kycSubmittedAt').sort({ kycSubmittedAt: 1 }).lean();
    res.json({ success:true, data: users });
  } catch(e) { return safeError(res, e, 'admin'); }
});

router.post('/kyc/review', async (req, res) => {
  try {
    const { userId, approve, reason } = req.body;
    const update = approve
      ? { kycStatus: 'verified', kycReviewedAt: new Date(), kycRejectReason: null }
      : { kycStatus: 'rejected', kycReviewedAt: new Date(), kycRejectReason: reason || 'Not specified' };
    const user = await User.findByIdAndUpdate(userId, { $set: update }, { new:true }).select('username kycStatus');
    if (!user) return res.status(404).json({ success:false, message:'User not found' });
    require('../services/notificationService').notify(userId, 'system', {
      title: approve ? 'KYC Approved' : 'KYC Rejected',
      message: approve ? 'Your identity verification was approved.' : `Your KYC was rejected: ${reason || 'contact support'}`
    }).catch(()=>{});
    audit('KYC_REVIEW', { username: user.username, approve, reason });
    require('../services/auditService').log('admin.kyc.review', { targetType:'User', targetId:userId, meta:{ approve, reason } });
    res.json({ success:true, data: user });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── API MONITORING (Football API / Odds API health) ──
router.get('/api-monitoring', async (req, res) => {
  try {
    const Match = require('../models/Match');
    const [totalMatches, withOdds, bySource, lastSync] = await Promise.all([
      Match.countDocuments(),
      Match.countDocuments({ hasOdds: true }),
      Match.aggregate([{ $group: { _id: '$source', count: { $sum: 1 } } }]),
      Match.findOne().sort({ updatedAt: -1 }).select('updatedAt').lean()
    ]);
    res.json({
      success: true,
      data: {
        totalMatches, withOdds, withoutOdds: totalMatches - withOdds,
        bySource, lastSyncAt: lastSync?.updatedAt || null,
        keysConfigured: {
          juanAiApi: !!process.env.JUANAI_API_KEY
        }
      }
    });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── PAYMENT MONITORING (M-Pesa health) ──
router.get('/payment-monitoring', async (req, res) => {
  try {
    const since24h = new Date(Date.now() - 24*3600*1000);
    const [depositsPending, depositsFailed, depositsOk, wdPending, wdFailed, wdOk] = await Promise.all([
      Transaction.countDocuments({ type:'deposit', status:'pending', createdAt:{ $gte: since24h } }),
      Transaction.countDocuments({ type:'deposit', status:'failed', createdAt:{ $gte: since24h } }),
      Transaction.countDocuments({ type:'deposit', status:'completed', createdAt:{ $gte: since24h } }),
      Transaction.countDocuments({ type:'withdrawal', status:'pending', createdAt:{ $gte: since24h } }),
      Transaction.countDocuments({ type:'withdrawal', status:'failed', createdAt:{ $gte: since24h } }),
      Transaction.countDocuments({ type:'withdrawal', status:'completed', createdAt:{ $gte: since24h } })
    ]);
    res.json({
      success: true,
      data: {
        deposits: { pending: depositsPending, failed: depositsFailed, completed: depositsOk },
        withdrawals: { pending: wdPending, failed: wdFailed, completed: wdOk },
        keysConfigured: {
          mpesaConsumerKey: !!process.env.MPESA_CONSUMER_KEY,
          mpesaConsumerSecret: !!process.env.MPESA_CONSUMER_SECRET,
          mpesaShortcode: !!process.env.MPESA_SHORTCODE
        }
      }
    });
  } catch(e) { return safeError(res, e, 'admin'); }
});

// ── HEALTH CHECK (for uptime monitoring / load balancers) ──
router.get('/health', async (req, res) => {
  try {
    const mongoose = require('mongoose');
    const dbState = mongoose.connection.readyState; // 1 = connected
    res.json({
      success: true,
      status: dbState === 1 ? 'healthy' : 'degraded',
      db: dbState === 1 ? 'connected' : 'disconnected',
      uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
  } catch(e) { console.error('[admin/health]', e.message); res.status(500).json({ success:false, status:'unhealthy', message:'Health check failed' }); }
});

// ── STORAGE: USAGE REPORT ──
// Shows actual MongoDB Atlas usage plus a per-collection breakdown, so the admin
// can see exactly what's using space before deleting anything.
router.get('/storage/stats', async (req, res) => {
  try {
    const { getStorageStatus } = require('../utils/storageMonitor');
    const s = await getStorageStatus();
    if (!s.available) return res.status(503).json({ success: false, message: s.message });

    res.json({
      success: true,
      // Existing fields the current frontend already reads — kept as-is so nothing breaks
      dbSizeBytes: s.dataSizeBytes,
      storageSizeBytes: s.totalSizeBytes,
      freeTierLimitBytes: s.limitBytes,
      collections: s.collections.map(c => ({ name: c.name, count: c.count })),
      // New fields: index size tracked separately (per the requirement that
      // indexes count too, not just raw data), graduated warning level, and
      // the full per-collection size breakdown for the dashboard to show.
      indexSizeBytes: s.indexSizeBytes,
      percentUsed: s.percentUsed,
      level: s.level,
      levelLabel: s.label,
      collectionsDetailed: s.collections
    });
  } catch (e) { return safeError(res, e, 'admin/storage-stats'); }
});

// ── STORAGE: CLEANUP ──
// Deliberately scoped to collections that are safe to trim: read notifications
// (pure UI convenience, no financial record) and old WalletHistory entries
// (an internal audit trail — Transaction, not WalletHistory, is the real
// user-facing financial record). Transaction, Bet, and admin audit logs are
// intentionally NOT exposed here — deleting those removes your own financial
// record and accountability trail, which causes far more harm than the storage
// they use. Old, settled Match/fixture documents are also safe to trim since
// they're just cached fixture data re-fetched from the football API anyway.
router.post('/storage/cleanup', async (req, res) => {
  try {
    const { target, olderThanDays } = req.body;
    const days = Math.max(7, parseInt(olderThanDays) || 90); // 7-day floor — prevents accidentally wiping very recent data
    const cutoff = new Date(Date.now() - days * 86400000);
    let deleted = 0;

    if (target === 'read_notifications') {
      const Notification = require('../models/Notification');
      const r = await Notification.deleteMany({ read: true, createdAt: { $lt: cutoff } });
      deleted = r.deletedCount;
    } else if (target === 'wallet_history') {
      const WalletHistory = require('../models/WalletHistory');
      const r = await WalletHistory.deleteMany({ createdAt: { $lt: cutoff } });
      deleted = r.deletedCount;
    } else if (target === 'old_matches') {
      const Match = require('../models/Match');
      const r = await Match.deleteMany({ status: 'finished', commenceTime: { $lt: cutoff } });
      deleted = r.deletedCount;
    } else if (target === 'login_log') {
      store.loginLog = store.loginLog.filter(l => new Date(l.createdAt) >= cutoff);
      deleted = 'trimmed in-memory log';
    } else {
      return res.status(400).json({ success: false, message: 'Unknown or disallowed cleanup target' });
    }

    audit('STORAGE_CLEANUP', { target, olderThanDays: days, deleted });
    res.json({ success: true, deleted, message: `Cleaned up ${target}` });
  } catch (e) { return safeError(res, e, 'admin/storage-cleanup'); }
});

module.exports = router;
