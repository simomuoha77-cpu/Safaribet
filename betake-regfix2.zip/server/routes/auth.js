const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const User    = require('../models/User');
const auth    = require('../middleware/auth');
const router  = express.Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'Too many login attempts. Try again in 15 minutes.' },
  standardHeaders: true, legacyHeaders: false
});

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { success: false, message: 'Too many registrations from this IP.' }
});

// ── REGISTER ──
router.post('/register', registerLimiter, async (req, res) => {
  try {
    let { username, phone, password } = req.body;

    if (!username || !phone || !password) {
      return res.status(400).json({ success: false, message: 'All fields required' });
    }
    username = username.trim().toLowerCase();
    phone = phone.replace(/\D/g, '');

    if (username.length < 3 || username.length > 24) {
      return res.status(400).json({ success: false, message: 'Username must be 3-24 characters' });
    }
    if (!/^[a-z0-9_]+$/.test(username)) {
      return res.status(400).json({ success: false, message: 'Username: letters, numbers, underscore only' });
    }
    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters' });
    }
    // Kenyan phone: 07XX or 01XX → normalize to 254
    if (phone.startsWith('0')) phone = '254' + phone.slice(1);
    // Accept any valid Kenyan mobile (07XX, 01XX)
    if (!/^254[0-9]{9}$/.test(phone)) {
      return res.status(400).json({ success: false, message: 'Enter a valid phone: 0712345678' });
    }

    const existsUsername = await User.findOne({ username });
    if (existsUsername) {
      return res.status(400).json({ success: false, message: 'Username already taken. Choose another.' });
    }
    const existsPhone = await User.findOne({ phone });
    if (existsPhone) {
      return res.status(400).json({ success: false, message: 'Phone number already registered. Try logging in.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ username, phone, passwordHash });

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({
      success: true,
      token,
      user: { id: user._id, username: user.username, balance: user.balance }
    });
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ success: false, message: 'Username or phone already taken' });
    console.error('[auth/register]', e.message);
    res.status(500).json({ success: false, message: 'Registration failed' });
  }
});

// ── LOGIN ──
router.post('/login', loginLimiter, async (req, res) => {
  try {
    // Accept phone or username as identifier
    const { username, phone, password } = req.body;
    const identifier = (phone || username || '').trim();
    if (!identifier || !password) {
      return res.status(400).json({ success: false, message: 'Phone number and password required' });
    }

    // Normalize phone if it looks like a phone number
    let query;
    const digitsOnly = identifier.replace(/\D/g,'');
    if (digitsOnly.length >= 9) {
      // It's a phone number — normalize and search by phone
      let normalized = digitsOnly;
      if (normalized.startsWith('0')) normalized = '254' + normalized.slice(1);
      if (!normalized.startsWith('254')) normalized = '254' + normalized;
      query = { phone: normalized };
    } else {
      // It's a username
      query = { username: identifier.toLowerCase() };
    }

    const user = await User.findOne(query);
    if (!user) return res.status(401).json({ success: false, message: 'Invalid credentials' });
    if (!user.isActive) return res.status(403).json({ success: false, message: 'Account suspended' });
    if (user.isLocked) return res.status(429).json({ success: false, message: 'Account locked. Try again in 15 minutes.' });

    const ok = await user.comparePassword(password);
    if (!ok) {
      await user.incLoginAttempts();
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    // Reset on success
    await user.updateOne({ $set: { loginAttempts: 0, lastLogin: new Date() }, $unset: { lockUntil: 1 } });

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({
      success: true,
      token,
      user: { id: user._id, username: user.username, balance: user.balance }
    });
  } catch (e) {
    console.error('[auth/login]', e.message);
    res.status(500).json({ success: false, message: 'Login failed' });
  }
});

// ── ME ──
router.get('/me', auth, async (req, res) => {
  res.json({ success: true, user: { id: req.user._id, username: req.user.username, balance: req.user.balance } });
});

// ── BALANCE ──
router.get('/balance', auth, async (req, res) => {
  const user = await User.findById(req.user._id).select('balance');
  res.json({ success: true, balance: user.balance });
});

// ── ADMIN: DELETE USER (for cleanup) ──
router.delete('/admin/user/:phone', async (req, res) => {
  if (req.headers['x-admin-secret'] !== process.env.ADMIN_PASSWORD)
    return res.status(401).json({ success: false });
  try {
    let phone = req.params.phone.replace(/\D/g,'');
    if (phone.startsWith('0')) phone = '254' + phone.slice(1);
    const user = await User.findOneAndDelete({ $or: [{ phone }, { username: req.params.phone }] });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, message: `Deleted user: ${user.username} (${user.phone})` });
  } catch(e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

module.exports = router;
