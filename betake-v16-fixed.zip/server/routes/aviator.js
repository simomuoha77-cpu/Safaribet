const express = require('express');
const crypto  = require('crypto');
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');

const router = express.Router();

// ─────────────────────────────────────────
//  IN-MEMORY RATE LIMITER (no npm needed)
//  Max 2 req/sec per IP on /state
// ─────────────────────────────────────────
const rateBuckets = new Map(); // ip -> { count, resetAt }
function rateLimit(maxPerSec) {
  return (req, res, next) => {
    const ip  = req.ip || req.connection.remoteAddress;
    const now = Date.now();
    let b = rateBuckets.get(ip);
    if (!b || now > b.resetAt) {
      b = { count: 0, resetAt: now + 1000 };
      rateBuckets.set(ip, b);
    }
    b.count++;
    if (b.count > maxPerSec) {
      return res.status(429).json({ success: false, message: 'Too many requests' });
    }
    next();
  };
}
// Clean buckets every 30s
setInterval(() => {
  const now = Date.now();
  for (const [ip, b] of rateBuckets) {
    if (now > b.resetAt + 5000) rateBuckets.delete(ip);
  }
}, 30000);

// ─────────────────────────────────────────
//  JWT AUTH MIDDLEWARE (for state endpoint)
// ─────────────────────────────────────────
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  try {
    const decoded = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    return res.status(401).json({ success: false, message: 'Invalid token' });
  }
}

// ─────────────────────────────────────────
//  BET VELOCITY TRACKER
//  Flag accounts only betting "safe" rounds
// ─────────────────────────────────────────
const betHistory = new Map(); // userId -> [{roundId, crashPoint, stake}]
const flaggedUsers = new Set();

function trackBetVelocity(userId, roundId, crashPoint, stake) {
  if (!betHistory.has(userId)) betHistory.set(userId, []);
  const hist = betHistory.get(userId);
  hist.push({ roundId, crashPoint, stake, ts: Date.now() });
  // Keep last 20 bets
  if (hist.length > 20) hist.shift();

  // Flag if: placed 5+ bets AND >80% of cashed bets were on rounds that crashed >2x
  if (hist.length >= 5) {
    const cashedRounds = hist.filter(h => h.cashoutAt && h.crashPoint > 2.0);
    const ratio = cashedRounds.length / hist.length;
    if (ratio > 0.8) {
      flaggedUsers.add(userId);
      console.warn(`⚠️  Suspicious bet pattern — userId: ${userId}`);
    }
  }
}

// ─────────────────────────────────────────
//  PROVABLY FAIR — SHA-512
// ─────────────────────────────────────────
function generateCrashPoint(serverSeed, clientSeed, nonce) {
  // SHA-512 based — same approach as Spribe/real Aviator
  const combined = `${serverSeed}:${clientSeed}:${nonce}`;
  const hash = crypto.createHash('sha512').update(combined).digest('hex');

  // Use first 8 hex chars -> 32-bit int
  const val = parseInt(hash.slice(0, 8), 16);
  const e   = 2 ** 32;
  const h   = val / e;

  // House edge 3% — ~1 in 33 rounds crashes at 1.00
  if (h < 0.03) return 1.00;
  return Math.max(1.00, parseFloat((0.97 / (1 - h)).toFixed(2)));
}

function generateClientSeed() {
  return crypto.randomBytes(8).toString('hex');
}

// ─────────────────────────────────────────
//  GAME STATE
// ─────────────────────────────────────────
let gs = {
  status:      'waiting',
  multiplier:  1.00,
  crashPoint:  null,   // NEVER sent to client until crashed
  serverSeed:  null,   // NEVER sent until crashed
  clientSeed:  null,
  nonce:       0,
  publicHash:  null,   // SHA-512 hash of serverSeed — sent upfront for provably fair
  roundId:     0,
  startTime:   null,
  crashTime:   null,
  players:     [],
  history:     []      // { crashPoint, serverSeed, clientSeed, nonce, hash }
};

let flyInterval  = null;
let waitInterval = null;
let wsClients    = new Set(); // WebSocket clients

// ─────────────────────────────────────────
//  WEBSOCKET BROADCAST
// ─────────────────────────────────────────
function broadcast(data) {
  const msg = JSON.stringify(data);
  for (const ws of wsClients) {
    if (ws.readyState === 1) { // OPEN
      try { ws.send(msg); } catch {}
    }
  }
}

function broadcastState() {
  broadcast(buildStatePayload());
}

function buildStatePayload() {
  return {
    type:        'state',
    status:      gs.status,
    multiplier:  gs.multiplier,
    // ✅ Only reveal crashPoint AFTER crash
    crashPoint:  gs.status === 'crashed' ? gs.crashPoint : null,
    serverSeed:  gs.status === 'crashed' ? gs.serverSeed : null,
    publicHash:  gs.publicHash,
    clientSeed:  gs.clientSeed,
    nonce:       gs.nonce,
    roundId:     gs.roundId,
    // elapsed time in flight — lets client sync position correctly
    elapsed:     gs.status === 'flying' && gs.startTime ? (Date.now() - gs.startTime) / 1000 : 0,
    history:     gs.history.slice(-20).map(h => ({
      crashPoint: h.crashPoint,
      hash:       h.hash,
      serverSeed: h.serverSeed,
      clientSeed: h.clientSeed,
      nonce:      h.nonce
    })),
    playerCount: gs.players.length
  };
}

// ─────────────────────────────────────────
//  GAME LOOP
// ─────────────────────────────────────────
function startNewRound() {
  clearInterval(flyInterval);
  clearInterval(waitInterval);

  const serverSeed = crypto.randomBytes(32).toString('hex');
  const clientSeed = generateClientSeed();
  const nonce      = gs.nonce + 1;
  const crashPoint = generateCrashPoint(serverSeed, clientSeed, nonce);
  // SHA-512 hash of full seed — published BEFORE round so players can verify later
  const publicHash = crypto.createHash('sha512').update(`${serverSeed}:${clientSeed}:${nonce}`).digest('hex');

  gs = {
    ...gs,
    status:     'waiting',
    multiplier: 1.00,
    crashPoint,          // stored server-side only
    serverSeed,          // stored server-side only
    clientSeed,
    nonce,
    publicHash,          // published upfront
    roundId:    gs.roundId + 1,
    startTime:  null,
    crashTime:  null,
    players:    []
  };

  broadcastState();

  // 5s betting window
  let countdown = 5;
  broadcast({ type: 'countdown', value: countdown });
  waitInterval = setInterval(() => {
    countdown--;
    broadcast({ type: 'countdown', value: countdown });
    if (countdown <= 0) {
      clearInterval(waitInterval);
      startFlying();
    }
  }, 1000);
}

function startFlying() {
  gs.status    = 'flying';
  gs.startTime = Date.now();
  broadcastState();

  flyInterval = setInterval(() => {
    const elapsed = (Date.now() - gs.startTime) / 1000;
    // Smooth exponential growth matching crash point
    const raw = Math.pow(Math.E, elapsed * 0.06 * Math.log(gs.crashPoint + 1));
    gs.multiplier = parseFloat(Math.min(raw, gs.crashPoint).toFixed(2));

    // Broadcast multiplier update to all clients
    broadcast({ type: 'tick', multiplier: gs.multiplier, roundId: gs.roundId });

    if (gs.multiplier >= gs.crashPoint) {
      clearInterval(flyInterval);
      gs.multiplier = gs.crashPoint;
      gs.status     = 'crashed';
      gs.crashTime  = Date.now();

      // ✅ Now reveal serverSeed for provably fair verification
      gs.history.push({
        crashPoint: gs.crashPoint,
        serverSeed: gs.serverSeed,
        clientSeed: gs.clientSeed,
        nonce:      gs.nonce,
        hash:       gs.publicHash
      });
      if (gs.history.length > 50) gs.history.shift();

      // Mark all uncashed players as lost
      gs.players.forEach(p => { if (!p.cashedOut) p.lost = true; });

      // ✅ Broadcast crash WITH serverSeed revealed
      broadcastState();
      broadcast({ type: 'crashed', crashPoint: gs.crashPoint, serverSeed: gs.serverSeed });

      setTimeout(startNewRound, 3500);
    }
  }, 100);
}

// Start on load
startNewRound();

// ─────────────────────────────────────────
//  WEBSOCKET SETUP (called from index.js)
// ─────────────────────────────────────────
router.setupWS = function(wss) {
  wss.on('connection', (ws, req) => {
    // ✅ Require JWT on WS connection
    const url   = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    if (!token) {
      ws.send(JSON.stringify({ type: 'error', message: 'Auth required' }));
      ws.close();
      return;
    }
    try {
      jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      ws.send(JSON.stringify({ type: 'error', message: 'Invalid token' }));
      ws.close();
      return;
    }

    wsClients.add(ws);
    // Send current state immediately on connect
    ws.send(JSON.stringify(buildStatePayload()));

    ws.on('close', () => wsClients.delete(ws));
    ws.on('error', () => wsClients.delete(ws));
  });
};

// ─────────────────────────────────────────
//  HTTP ROUTES (fallback for non-WS clients)
// ─────────────────────────────────────────

// GET /api/aviator/state — public (view only), rate limited
router.get('/state', rateLimit(4), (req, res) => {
  res.json({ success: true, data: buildStatePayload() });
});

// GET /api/aviator/verify — verify a past round provably fair
router.get('/verify/:roundHash', requireAuth, (req, res) => {
  const entry = gs.history.find(h => h.hash === req.params.roundHash);
  if (!entry) return res.status(404).json({ success: false, message: 'Round not found' });

  const computed = generateCrashPoint(entry.serverSeed, entry.clientSeed, entry.nonce);
  const valid    = computed === entry.crashPoint;
  res.json({ success: true, valid, computed, stored: entry.crashPoint, entry });
});

// POST /api/aviator/bet
router.post('/bet', requireAuth, async (req, res) => {
  try {
    const { stake, autoCashout } = req.body;
    const userId = req.userId;

    if (gs.status !== 'waiting') {
      return res.status(400).json({ success: false, message: 'Betting closed. Wait for next round.' });
    }
    if (!stake || stake < 10) {
      return res.status(400).json({ success: false, message: 'Minimum stake is KES 10' });
    }
    if (autoCashout && (autoCashout < 1.01 || autoCashout > 1000)) {
      return res.status(400).json({ success: false, message: 'Auto cashout must be between 1.01 and 1000' });
    }
    if (gs.players.find(p => p.userId === userId)) {
      return res.status(400).json({ success: false, message: 'Bet already placed this round' });
    }

    const user = await User.findById(userId);
    if (!user || user.balance < stake) {
      return res.status(400).json({ success: false, message: 'Insufficient balance' });
    }

    // Check flagged users — limit stake
    if (flaggedUsers.has(userId) && stake > 500) {
      return res.status(403).json({ success: false, message: 'Stake limit applied. Contact support.' });
    }

    user.balance -= parseFloat(stake);
    await user.save();

    const player = {
      userId,
      username:        user.username,
      stake:           parseFloat(stake),
      autoCashout:     autoCashout ? parseFloat(autoCashout) : null,
      cashedOut:       false,
      cashoutAt:       null,
      cashoutMultiplier: null,
      won:             0,
      betTime:         Date.now(),
      roundId:         gs.roundId
    };
    gs.players.push(player);

    trackBetVelocity(userId, gs.roundId, gs.crashPoint, stake);

    // Broadcast updated player list
    broadcast({ type: 'players', players: sanitisePlayers() });

    res.json({ success: true, message: 'Bet placed', newBalance: user.balance, roundId: gs.roundId });
  } catch (err) {
    console.error('Bet error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/aviator/cashout
router.post('/cashout', requireAuth, async (req, res) => {
  try {
    const userId   = req.userId;
    const now      = Date.now();

    // ✅ Server-side cashout time validation
    if (gs.status !== 'flying') {
      return res.status(400).json({ success: false, message: 'Game not active' });
    }

    const player = gs.players.find(p => p.userId === userId && !p.cashedOut);
    if (!player) {
      return res.status(400).json({ success: false, message: 'No active bet found' });
    }

    // ✅ Verify cashout happened BEFORE crash time
    if (gs.crashTime && now >= gs.crashTime) {
      return res.status(400).json({ success: false, message: 'Cashout rejected — round already crashed' });
    }

    // ✅ Re-compute multiplier server-side at exact cashout time
    const elapsed   = (now - gs.startTime) / 1000;
    const serverMulti = parseFloat(
      Math.min(
        Math.pow(Math.E, elapsed * 0.06 * Math.log(gs.crashPoint + 1)),
        gs.crashPoint
      ).toFixed(2)
    );

    // Reject if server multi already >= crashPoint
    if (serverMulti >= gs.crashPoint) {
      return res.status(400).json({ success: false, message: 'Too late — plane already crashed' });
    }

    const winAmount = parseFloat((player.stake * serverMulti).toFixed(2));

    player.cashedOut        = true;
    player.cashoutAt        = now;
    player.cashoutMultiplier = serverMulti;
    player.won              = winAmount;

    // Track for velocity analysis
    const hist = betHistory.get(userId);
    if (hist && hist.length) hist[hist.length - 1].cashoutAt = serverMulti;

    const user = await User.findById(userId);
    user.balance += winAmount;
    await user.save();

    // Broadcast cashout event to all players (live feed)
    broadcast({
      type:       'cashout',
      username:   player.username,
      multiplier: serverMulti,
      won:        winAmount,
      roundId:    gs.roundId
    });
    broadcast({ type: 'players', players: sanitisePlayers() });

    res.json({ success: true, multiplier: serverMulti, won: winAmount, newBalance: user.balance });
  } catch (err) {
    console.error('Cashout error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/aviator/players
router.get('/players', requireAuth, rateLimit(5), (req, res) => {
  res.json({ success: true, data: sanitisePlayers() });
});

function sanitisePlayers() {
  return gs.players.map(p => ({
    username:          p.username,
    stake:             p.stake,
    cashedOut:         p.cashedOut,
    cashoutMultiplier: p.cashoutMultiplier,
    won:               p.won
  }));
}

module.exports = router;
