const express = require('express');
const crypto = require('crypto');
const { protect } = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// Active game state (in-memory, single instance)
let gameState = {
  status: 'waiting', // waiting | flying | crashed
  multiplier: 1.00,
  crashPoint: null,
  serverSeed: null,
  publicHash: null,
  roundId: 0,
  startTime: null,
  players: [], // { userId, username, stake, cashedOut, cashoutMultiplier }
  history: [] // last 20 crash points
};

let gameInterval = null;
let waitInterval = null;

// ─── PROVABLY FAIR CRASH POINT ───
function generateCrashPoint(serverSeed) {
  const hash = crypto.createHmac('sha256', serverSeed).update('aviator').digest('hex');
  const val = parseInt(hash.slice(0, 8), 16);
  // House edge ~3%. Formula similar to real Aviator
  const e = 2 ** 32;
  const h = val / e;
  if (h < 0.03) return 1.00; // instant crash (house edge)
  return Math.max(1.00, parseFloat((1 / (1 - h) * 0.97).toFixed(2)));
}

function startNewRound() {
  const serverSeed = crypto.randomBytes(32).toString('hex');
  const crashPoint = generateCrashPoint(serverSeed);
  const publicHash = crypto.createHash('sha256').update(serverSeed).digest('hex');

  gameState = {
    status: 'waiting',
    multiplier: 1.00,
    crashPoint,
    serverSeed: null, // revealed after crash
    publicHash,
    roundId: gameState.roundId + 1,
    startTime: null,
    players: [],
    history: gameState.history.slice(-19)
  };

  // Wait 5 seconds for bets
  let countdown = 5;
  waitInterval = setInterval(() => {
    countdown--;
    if (countdown <= 0) {
      clearInterval(waitInterval);
      startFlying(serverSeed, crashPoint);
    }
  }, 1000);
}

function startFlying(serverSeed, crashPoint) {
  gameState.status = 'flying';
  gameState.startTime = Date.now();

  gameInterval = setInterval(() => {
    const elapsed = (Date.now() - gameState.startTime) / 1000;
    // Multiplier grows exponentially like real Aviator
    gameState.multiplier = parseFloat(Math.pow(Math.E, elapsed * 0.06 * Math.log(crashPoint + 1)).toFixed(2));
    gameState.multiplier = Math.min(gameState.multiplier, crashPoint);

    if (gameState.multiplier >= crashPoint) {
      clearInterval(gameInterval);
      gameState.multiplier = crashPoint;
      gameState.status = 'crashed';
      gameState.serverSeed = serverSeed; // reveal seed after crash
      gameState.history.push(crashPoint);

      // Auto cashout anyone who didn't cash out
      gameState.players.forEach(p => {
        if (!p.cashedOut) p.lost = true;
      });

      // Start next round after 3 seconds
      setTimeout(startNewRound, 3000);
    }
  }, 100);
}

// Start first round on load
startNewRound();

// ─── ROUTES ───

// GET /api/aviator/state — get current game state (no auth needed for display)
router.get('/state', (req, res) => {
  res.json({
    success: true,
    data: {
      status: gameState.status,
      multiplier: gameState.multiplier,
      crashPoint: gameState.status === 'crashed' ? gameState.crashPoint : null,
      publicHash: gameState.publicHash,
      serverSeed: gameState.status === 'crashed' ? gameState.serverSeed : null,
      roundId: gameState.roundId,
      history: gameState.history,
      playerCount: gameState.players.length
    }
  });
});

// POST /api/aviator/bet — place a bet for current round
router.post('/bet', protect, async (req, res) => {
  try {
    const { stake } = req.body;
    const userId = req.user._id.toString();

    if (gameState.status !== 'waiting') {
      return res.status(400).json({ success: false, message: 'Betting is closed. Wait for next round.' });
    }
    if (!stake || stake < 10) {
      return res.status(400).json({ success: false, message: 'Minimum bet is KES 10' });
    }

    const user = await User.findById(userId);
    if (!user || user.balance < stake) {
      return res.status(400).json({ success: false, message: 'Insufficient balance' });
    }

    // Check not already betting
    if (gameState.players.find(p => p.userId === userId)) {
      return res.status(400).json({ success: false, message: 'You already have a bet this round' });
    }

    // Deduct balance
    user.balance -= stake;
    await user.save();

    gameState.players.push({
      userId,
      username: user.username,
      stake: parseFloat(stake),
      cashedOut: false,
      cashoutMultiplier: null,
      won: 0
    });

    res.json({
      success: true,
      message: 'Bet placed',
      newBalance: user.balance
    });
  } catch (err) {
    console.error('Aviator bet error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/aviator/cashout — cash out current bet
router.post('/cashout', protect, async (req, res) => {
  try {
    const userId = req.user._id.toString();

    if (gameState.status !== 'flying') {
      return res.status(400).json({ success: false, message: 'Game is not active' });
    }

    const player = gameState.players.find(p => p.userId === userId && !p.cashedOut);
    if (!player) {
      return res.status(400).json({ success: false, message: 'No active bet found' });
    }

    const currentMultiplier = gameState.multiplier;
    const winAmount = parseFloat((player.stake * currentMultiplier).toFixed(2));

    player.cashedOut = true;
    player.cashoutMultiplier = currentMultiplier;
    player.won = winAmount;

    // Credit user
    const user = await User.findById(userId);
    user.balance += winAmount;
    await user.save();

    res.json({
      success: true,
      multiplier: currentMultiplier,
      won: winAmount,
      newBalance: user.balance
    });
  } catch (err) {
    console.error('Aviator cashout error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/aviator/players — live players in current round
router.get('/players', (req, res) => {
  const players = gameState.players.map(p => ({
    username: p.username,
    stake: p.stake,
    cashedOut: p.cashedOut,
    cashoutMultiplier: p.cashoutMultiplier,
    won: p.won
  }));
  res.json({ success: true, data: players });
});

module.exports = router;
